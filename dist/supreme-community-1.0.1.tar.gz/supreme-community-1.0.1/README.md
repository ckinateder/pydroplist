# supreme-community

A python module to grab data from <https://supremecommunity.com> and list products on the next drop.

## Installation

Install via `pip install supreme-community`.

## Usage

First import to your project with `import supreme-community`.
To use, call the function `latest()` – this returns a list of the products dropping