# pydroplist

A python module to grab data from droplists online and list products on the next drop, given the brand being searched for.

## Installation

Install via `pip install pydroplist`.

## Usage

First import to your project with `import pydroplist`.
To use, call the function `latest('brand')` – this returns a list of the products dropping. Input the brand you are looking for.
Currently only supports `'supreme'` as an argument – will be adding more later.
